/* 
	環境變數
*/
resource_group_name = "rg-terra-demo"
location            = "East Asia"
vnet_name           = "vnet-demo"
subnet_name			= "subnet-demo"