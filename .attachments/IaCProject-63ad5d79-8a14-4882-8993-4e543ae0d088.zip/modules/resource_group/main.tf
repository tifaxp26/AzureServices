/*
	模組主程式
*/

resource "azurerm_resource_group" "rg" {
  name     = var.resource_group_name
  location = var.location
}


# Resource Group
# resource "azurerm_resource_group" "rg" {
#   name     = "rg-terraform-demo"
#   location = "East Asia"
# }

