/*
	代表這個 module 需要參數
*/

variable "resource_group_name" {
  type = string
}

variable "location" {
	description = "Azure region"
	type = string
	default = "East Asia"
}