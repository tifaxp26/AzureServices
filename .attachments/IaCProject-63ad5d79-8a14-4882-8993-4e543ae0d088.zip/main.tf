/*
	Root 主程式
*/

provider "azurerm" {
  features {}
}

module "resource_group" {
	source = "./modules/resource_group"

	# 變數傳遞到模組內
	resource_group_name = var.resource_group_name
	location            = var.location
}


module "vnet" {
	source = "./modules/vnet"

	# 變數傳遞到模組內
	# resource_group_name = var.resource_group_name
	# 用 module output 建立依賴
	resource_group_name = module.resource_group.resource_group_name
	location            = var.location
	vnet_name			= var.vnet_name
	subnet_name			= var.subnet_name
}




## Resource Group
#resource "azurerm_resource_group" "rg" {
#  name     = "rg-terraform-demo"
#  location = "East Asia"
#}
#
#
## Virtual Network
#resource "azurerm_virtual_network" "vnet" {
#  name                = "vnet-demo"
#  location            = azurerm_resource_group.rg.location
#  resource_group_name = azurerm_resource_group.rg.name
#  address_space       = ["10.0.0.0/16"]
#}
#
## Subnet
#resource "azurerm_subnet" "subnet1" {
#  name                 = "subnet-demo"
#  resource_group_name  = azurerm_resource_group.rg.name
#  virtual_network_name = azurerm_virtual_network.vnet.name
#  address_prefixes     = ["10.0.1.0/24"]
#}