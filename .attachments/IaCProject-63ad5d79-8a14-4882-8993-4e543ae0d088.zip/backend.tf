/*
	Terraform backend 設定
	使用 Azure Storage Remote State 會得到：
	功能	說明
	State Lock	避免同時 apply
	團隊共用	所有人用同一份 state
	安全	RBAC 控制
	CI/CD	Pipeline 可讀
	Backup	Azure 自動備份
*/
terraform {
  backend "azurerm" {
    resource_group_name  = "rg-walsin-development"
    storage_account_name = "stwalsindevelopment01"
    container_name       = "tfstate"
    key                  = "prod.terraform.tfstate"
  }
}