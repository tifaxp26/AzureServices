/*
	代表這個 module 需要參數
*/

variable "resource_group_name" {
  type = string
}

variable "location" {
  type = string
}

variable "vnet_name" {
  type = string
}

variable "subnet_name" {
  type = string
}

#variable "address_space" {
#  type = string
#}
#
#variable "address_prefixes" {
#  type = string
#}