output "vnet_name" {
  description = "VNet Name"
  value       = azurerm_virtual_network.vnet.name
}

output "subnet_name" {
  description = "Subnet Name"
  value       = azurerm_subnet.subnet1.name
}