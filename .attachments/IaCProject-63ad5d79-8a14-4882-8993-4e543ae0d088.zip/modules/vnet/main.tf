/*
	模組主程式
*/

resource "azurerm_virtual_network" "vnet" {
	name     			= var.vnet_name  
	location            = var.location
	resource_group_name = var.resource_group_name
	address_space       = ["10.0.0.0/16"]
}

# Subnet
resource "azurerm_subnet" "subnet1" {
  name                 = var.subnet_name
  resource_group_name  = var.resource_group_name
  virtual_network_name = azurerm_virtual_network.vnet.name
  address_prefixes     = ["10.0.1.0/24"]
}



# Virtual Network
# resource "azurerm_virtual_network" "vnet" {
#   name                = "vnet-demo"
#   location            = azurerm_resource_group.rg.location
#   resource_group_name = azurerm_resource_group.rg.name
#   address_space       = ["10.0.0.0/16"]
# }
 
# Subnet
# resource "azurerm_subnet" "subnet1" {
#   name                 = "subnet-demo"
#   resource_group_name  = azurerm_resource_group.rg.name
#   virtual_network_name = azurerm_virtual_network.vnet.name
#   address_prefixes     = ["10.0.1.0/24"]
# }